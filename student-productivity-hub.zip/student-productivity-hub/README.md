# Student Productivity Hub

A responsive productivity dashboard for college students, built with **React + TypeScript + Tailwind CSS** (Vite).
No backend and no paid services: all data lives in the browser's `localStorage` and survives refresh.

## Features
- **Dashboard**: greeting, date, task and assignment stats, daily progress, upcoming deadlines, recent activity
- **To-Do List**: add, edit, delete, complete; High/Medium/Low priority; All/Pending/Completed filters
- **Study Planner**: daily and weekly timetable; add, edit, delete sessions with time validation
- **Assignment Tracker**: deadlines, status (Not Started / In Progress / Completed), overdue and due-soon highlighting
- **Study Notes**: create, edit, delete, search; auto-saves on every change
- **Progress Tracker**: completion percentage, 7-day chart, weekly statistics
- Collapsible desktop sidebar, bottom navigation on mobile, success/error toasts, sample data on first visit

## Run locally
```bash
npm install
npm run dev      # http://localhost:5173
npm run build    # production build in dist/
```
To reset to the sample data, run `localStorage.clear()` in the browser console and refresh.

## Structure
```
src/
  components/  Layout (sidebar + mobile nav), ui (Card, Btn, Modal, Field...)
  pages/       Dashboard, Todos, Planner, Assignments, Notes, Progress
  hooks/       useLocalStorage
  data/        sample data
  lib/         date helpers
  store.tsx    app state (context), toasts, activity log
  types.ts     shared TypeScript types
```
