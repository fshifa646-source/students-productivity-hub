export const uid = () => Math.random().toString(36).slice(2, 10);
export const iso = (d: Date) => d.toLocaleDateString('en-CA'); // yyyy-mm-dd, local time
export const today = () => iso(new Date());
export const addDays = (n: number) => { const d = new Date(); d.setDate(d.getDate() + n); return iso(d); };
export const fmtDate = (s: string) =>
  new Date(s + 'T00:00:00').toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
export const ago = (ts: number) => {
  const m = Math.round((Date.now() - ts) / 60000);
  return m < 1 ? 'just now' : m < 60 ? `${m}m ago` : m < 1440 ? `${Math.round(m / 60)}h ago` : `${Math.round(m / 1440)}d ago`;
};
export const mins = (t: string) => { const [h, m] = t.split(':').map(Number); return h * 60 + m; };
export const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
export const todayIdx = () => (new Date().getDay() + 6) % 7;
