import { createContext, Dispatch, ReactNode, SetStateAction, useCallback, useContext, useRef, useState } from 'react';
import { Activity, Assignment, Note, Session, Task, ToastMsg } from './types';
import { useLocalStorage } from './hooks/useLocalStorage';
import { sampleActivity, sampleAssignments, sampleNotes, sampleSessions, sampleTasks } from './data/sample';
import { uid } from './lib/utils';

type Set<T> = Dispatch<SetStateAction<T>>;
interface Ctx {
  tasks: Task[]; setTasks: Set<Task[]>;
  sessions: Session[]; setSessions: Set<Session[]>;
  assignments: Assignment[]; setAssignments: Set<Assignment[]>;
  notes: Note[]; setNotes: Set<Note[]>;
  activity: Activity[];
  log: (text: string) => void;
  toast: ToastMsg | null;
  notify: (text: string, type?: ToastMsg['type']) => void;
}
const AppCtx = createContext<Ctx | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [tasks, setTasks] = useLocalStorage('sph.tasks', sampleTasks());
  const [sessions, setSessions] = useLocalStorage('sph.sessions', sampleSessions());
  const [assignments, setAssignments] = useLocalStorage('sph.assignments', sampleAssignments());
  const [notes, setNotes] = useLocalStorage('sph.notes', sampleNotes());
  const [activity, setActivity] = useLocalStorage('sph.activity', sampleActivity());
  const [toast, setToast] = useState<ToastMsg | null>(null);
  const timer = useRef<number>();

  const log = useCallback((text: string) => setActivity((p) => [{ id: uid(), text, at: Date.now() }, ...p].slice(0, 30)), [setActivity]);
  const notify = useCallback((text: string, type: ToastMsg['type'] = 'success') => {
    setToast({ text, type });
    window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => setToast(null), 2600);
  }, []);

  return (
    <AppCtx.Provider value={{ tasks, setTasks, sessions, setSessions, assignments, setAssignments, notes, setNotes, activity, log, toast, notify }}>
      {children}
    </AppCtx.Provider>
  );
}
export const useApp = () => {
  const c = useContext(AppCtx);
  if (!c) throw new Error('useApp must be used inside AppProvider');
  return c;
};
