import { Bar, Card, PageHead } from '../components/ui';
import { useApp } from '../store';
import { addDays, iso, mins } from '../lib/utils';

export default function Progress() {
  const { tasks, assignments, sessions } = useApp();
  const pct = tasks.length ? Math.round((tasks.filter((t) => t.done).length / tasks.length) * 100) : 0;
  const days = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(); d.setDate(d.getDate() - (6 - i));
    const key = iso(d);
    return { label: d.toLocaleDateString(undefined, { weekday: 'short' }), count: tasks.filter((t) => t.completedAt === key).length };
  });
  const max = Math.max(1, ...days.map((d) => d.count));
  const weekDone = days.reduce((s, d) => s + d.count, 0);
  const hours = (sessions.reduce((s, x) => s + (mins(x.end) - mins(x.start)), 0) / 60).toFixed(1);
  const byStatus = ['Not Started', 'In Progress', 'Completed'].map((s) => ({ s, n: assignments.filter((a) => a.status === s).length }));
  const dueWeek = assignments.filter((a) => a.status !== 'Completed' && a.deadline >= addDays(0) && a.deadline <= addDays(7)).length;

  return (
    <>
      <PageHead title="Progress Tracker" sub="See how your productivity is trending" />
      <div className="grid gap-4 md:grid-cols-3">
        <Card className="text-center">
          <div className="mx-auto grid h-32 w-32 place-items-center rounded-full" style={{ background: `conic-gradient(#7c3aed ${pct * 3.6}deg, #ede9fe 0)` }}>
            <div className="grid h-24 w-24 place-items-center rounded-full bg-white text-2xl font-extrabold text-violet-700">{pct}%</div>
          </div>
          <p className="mt-3 text-sm font-semibold text-slate-600">Tasks completed</p>
        </Card>
        <Card>
          <p className="text-3xl font-extrabold text-sky-600">{weekDone}</p><p className="text-sm text-slate-600">Tasks completed in the last 7 days</p>
          <p className="mt-4 text-3xl font-extrabold text-violet-600">{hours}h</p><p className="text-sm text-slate-600">Study time planned each week</p>
        </Card>
        <Card>
          <p className="text-3xl font-extrabold text-amber-600">{dueWeek}</p><p className="text-sm text-slate-600">Assignments due in the next 7 days</p>
          <div className="mt-4 space-y-2">
            {byStatus.map(({ s, n }) => (
              <div key={s}><div className="flex justify-between text-xs font-semibold"><span>{s}</span><span>{n}</span></div><Bar pct={assignments.length ? (n / assignments.length) * 100 : 0} color="bg-sky-400" /></div>
            ))}
          </div>
        </Card>
      </div>
      <Card className="mt-4">
        <h2 className="mb-4 font-bold">Tasks completed per day (last 7 days)</h2>
        <div className="flex h-48 items-end gap-2 sm:gap-4">
          {days.map((d, i) => (
            <div key={i} className="flex h-full flex-1 flex-col items-center justify-end gap-1">
              <span className="text-xs font-semibold text-slate-600">{d.count}</span>
              <div className="w-full max-w-12 rounded-t-lg bg-gradient-to-t from-violet-600 to-sky-400 transition-all duration-500" style={{ height: `${(d.count / max) * 70 + 4}%` }} />
              <span className="text-xs text-slate-500">{d.label}</span>
            </div>
          ))}
        </div>
      </Card>
    </>
  );
}
