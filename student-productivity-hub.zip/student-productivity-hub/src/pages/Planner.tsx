import { FormEvent, useState } from 'react';
import { Btn, Card, Empty, Field, inputCls, Modal, PageHead } from '../components/ui';
import { useApp } from '../store';
import { Session } from '../types';
import { DAYS, mins, todayIdx, uid } from '../lib/utils';

const blank = { subject: '', topic: '', day: todayIdx(), start: '09:00', end: '10:00' };

export default function Planner() {
  const { sessions, setSessions, log, notify } = useApp();
  const [view, setView] = useState<'Daily' | 'Weekly'>('Weekly');
  const [day, setDay] = useState(todayIdx());
  const [open, setOpen] = useState(false);
  const [edit, setEdit] = useState<Session | null>(null);
  const [f, setF] = useState(blank);
  const [errs, setErrs] = useState<Record<string, string>>({});

  const openForm = (s?: Session) => {
    setEdit(s ?? null);
    setF(s ? { subject: s.subject, topic: s.topic, day: s.day, start: s.start, end: s.end } : { ...blank, day: view === 'Daily' ? day : todayIdx() });
    setErrs({}); setOpen(true);
  };
  const submit = (e: FormEvent) => {
    e.preventDefault();
    const er: Record<string, string> = {};
    if (!f.subject.trim()) er.subject = 'Enter a subject name.';
    if (!f.topic.trim()) er.topic = 'Enter a topic.';
    if (mins(f.end) <= mins(f.start)) er.end = 'End time must be after start time.';
    setErrs(er);
    if (Object.keys(er).length) return;
    const data = { ...f, subject: f.subject.trim(), topic: f.topic.trim() };
    if (edit) { setSessions((p) => p.map((s) => (s.id === edit.id ? { ...s, ...data } : s))); notify('Session updated'); }
    else { setSessions((p) => [...p, { id: uid(), ...data }]); log(`Planned ${data.subject} on ${DAYS[data.day]}`); notify('Session added'); }
    setOpen(false);
  };
  const del = (s: Session) => { if (!window.confirm(`Delete ${s.subject} session?`)) return; setSessions((p) => p.filter((x) => x.id !== s.id)); notify('Session deleted'); };
  const forDay = (d: number) => sessions.filter((s) => s.day === d).sort((a, b) => a.start.localeCompare(b.start));

  const item = (s: Session) => (
    <div key={s.id} className="rounded-xl bg-violet-50 p-3 text-sm">
      <p className="font-bold text-violet-800">{s.subject}</p>
      <p className="text-slate-600">{s.topic}</p>
      <p className="mt-1 text-xs font-semibold text-sky-700">{s.start} to {s.end}</p>
      <div className="mt-2 flex gap-3 text-xs"><button onClick={() => openForm(s)} className="text-violet-600 hover:underline">Edit</button><button onClick={() => del(s)} className="text-rose-600 hover:underline">Delete</button></div>
    </div>
  );

  return (
    <>
      <PageHead title="Study Planner" sub="Plan your week and stay consistent" action={<Btn onClick={() => openForm()}>+ Add session</Btn>} />
      <div className="mb-4 flex flex-wrap gap-2">
        {(['Daily', 'Weekly'] as const).map((v) => (
          <button key={v} onClick={() => setView(v)} className={`rounded-full px-4 py-1.5 text-sm font-semibold ${view === v ? 'bg-violet-600 text-white' : 'bg-white text-slate-600 ring-1 ring-violet-100'}`}>{v}</button>
        ))}
        {view === 'Daily' && DAYS.map((d, i) => (
          <button key={d} onClick={() => setDay(i)} className={`rounded-full px-3 py-1.5 text-sm font-semibold ${day === i ? 'bg-sky-500 text-white' : 'bg-white text-slate-600 ring-1 ring-sky-100'}`}>{d}</button>
        ))}
      </div>
      {view === 'Daily' ? (
        <Card>{forDay(day).length === 0 ? <Empty text={`Nothing planned for ${DAYS[day]}. Add a session.`} /> : <div className="grid gap-3 sm:grid-cols-2">{forDay(day).map(item)}</div>}</Card>
      ) : (
        <div className="grid gap-3 md:grid-cols-4 xl:grid-cols-7">
          {DAYS.map((d, i) => (
            <Card key={d} className={`p-3 ${i === todayIdx() ? 'ring-2 ring-violet-400' : ''}`}>
              <h3 className="mb-2 text-sm font-extrabold text-violet-700">{d}</h3>
              <div className="space-y-2">{forDay(i).length ? forDay(i).map(item) : <p className="text-xs text-slate-400">Free day</p>}</div>
            </Card>
          ))}
        </div>
      )}
      <Modal open={open} title={edit ? 'Edit session' : 'Add session'} onClose={() => setOpen(false)}>
        <form onSubmit={submit} className="space-y-4">
          <Field label="Subject" error={errs.subject}><input className={inputCls} value={f.subject} onChange={(e) => setF({ ...f, subject: e.target.value })} /></Field>
          <Field label="Topic" error={errs.topic}><input className={inputCls} value={f.topic} onChange={(e) => setF({ ...f, topic: e.target.value })} /></Field>
          <Field label="Day"><select className={inputCls} value={f.day} onChange={(e) => setF({ ...f, day: Number(e.target.value) })}>{DAYS.map((d, i) => <option key={d} value={i}>{d}</option>)}</select></Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Start"><input type="time" className={inputCls} value={f.start} onChange={(e) => setF({ ...f, start: e.target.value })} /></Field>
            <Field label="End" error={errs.end}><input type="time" className={inputCls} value={f.end} onChange={(e) => setF({ ...f, end: e.target.value })} /></Field>
          </div>
          <Btn type="submit" className="w-full">{edit ? 'Save changes' : 'Add session'}</Btn>
        </form>
      </Modal>
    </>
  );
}
