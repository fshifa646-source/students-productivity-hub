import { useState } from 'react';
import { Btn, Card, Empty, inputCls, PageHead } from '../components/ui';
import { useApp } from '../store';
import { Note } from '../types';
import { ago, uid } from '../lib/utils';

export default function Notes() {
  const { notes, setNotes, log, notify } = useApp();
  const [q, setQ] = useState('');
  const [sel, setSel] = useState<string | null>(notes[0]?.id ?? null);
  const cur = notes.find((n) => n.id === sel);
  const list = notes.filter((n) => (n.title + ' ' + n.body).toLowerCase().includes(q.toLowerCase())).sort((a, b) => b.updatedAt - a.updatedAt);

  const add = () => {
    const n: Note = { id: uid(), title: 'Untitled note', body: '', updatedAt: Date.now() };
    setNotes((p) => [n, ...p]); setSel(n.id); setQ(''); log('Created a new note'); notify('Note created');
  };
  // Every keystroke updates state and (via useLocalStorage) localStorage: auto-save.
  const upd = (patch: Partial<Note>) => setNotes((p) => p.map((n) => (n.id === sel ? { ...n, ...patch, updatedAt: Date.now() } : n)));
  const del = () => {
    if (!cur || !window.confirm(`Delete "${cur.title || 'Untitled'}"?`)) return;
    setNotes((p) => p.filter((n) => n.id !== cur.id)); setSel(null); notify('Note deleted');
  };

  return (
    <>
      <PageHead title="Study Notes" sub="Changes save automatically" action={<Btn onClick={add}>+ New note</Btn>} />
      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-1">
          <input className={`${inputCls} mb-3`} placeholder="Search notes..." value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search notes" />
          {list.length === 0 ? <Empty text={q ? 'No notes match your search.' : 'No notes yet. Create one.'} /> : (
            <ul className="max-h-96 space-y-2 overflow-auto">
              {list.map((n) => (
                <li key={n.id}>
                  <button onClick={() => setSel(n.id)} className={`w-full rounded-xl p-3 text-left transition ${sel === n.id ? 'bg-violet-100' : 'bg-violet-50/50 hover:bg-violet-50'}`}>
                    <p className="truncate text-sm font-bold">{n.title || 'Untitled'}</p>
                    <p className="truncate text-xs text-slate-500">{n.body || 'Empty note'}</p>
                    <p className="mt-1 text-[11px] text-slate-400">{ago(n.updatedAt)}</p>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </Card>
        <Card className="lg:col-span-2">
          {!cur ? <Empty text="Select a note or create a new one." /> : (
            <div className="space-y-3">
              <input className={`${inputCls} text-base font-bold`} value={cur.title} onChange={(e) => upd({ title: e.target.value })} placeholder="Note title" aria-label="Note title" />
              {!cur.title.trim() && <p className="text-xs text-rose-600">Add a title so you can find this note later.</p>}
              <textarea rows={12} className={inputCls} value={cur.body} onChange={(e) => upd({ body: e.target.value })} placeholder="Write your notes here..." aria-label="Note content" />
              <div className="flex items-center justify-between">
                <span className="text-xs text-emerald-600">✓ Saved automatically · {ago(cur.updatedAt)}</span>
                <Btn variant="danger" onClick={del}>Delete note</Btn>
              </div>
            </div>
          )}
        </Card>
      </div>
    </>
  );
}
