import { FormEvent, useState } from 'react';
import { Badge, Btn, Card, Empty, Field, inputCls, Modal, PageHead, STATUS } from '../components/ui';
import { useApp } from '../store';
import { Assignment, Status } from '../types';
import { addDays, fmtDate, today, uid } from '../lib/utils';

const STATUSES: Status[] = ['Not Started', 'In Progress', 'Completed'];
const blank = { title: '', subject: '', description: '', deadline: addDays(7), status: 'Not Started' as Status };

export default function Assignments() {
  const { assignments, setAssignments, log, notify } = useApp();
  const [open, setOpen] = useState(false);
  const [edit, setEdit] = useState<Assignment | null>(null);
  const [f, setF] = useState(blank);
  const [errs, setErrs] = useState<Record<string, string>>({});

  const openForm = (a?: Assignment) => {
    setEdit(a ?? null);
    setF(a ? { title: a.title, subject: a.subject, description: a.description, deadline: a.deadline, status: a.status } : blank);
    setErrs({}); setOpen(true);
  };
  const submit = (e: FormEvent) => {
    e.preventDefault();
    const er: Record<string, string> = {};
    if (f.title.trim().length < 3) er.title = 'Title must be at least 3 characters.';
    if (!f.subject.trim()) er.subject = 'Enter a subject.';
    if (!f.deadline) er.deadline = 'Choose a submission deadline.';
    setErrs(er);
    if (Object.keys(er).length) return;
    const data = { ...f, title: f.title.trim(), subject: f.subject.trim(), description: f.description.trim() };
    if (edit) { setAssignments((p) => p.map((a) => (a.id === edit.id ? { ...a, ...data } : a))); notify('Assignment updated'); }
    else { setAssignments((p) => [...p, { id: uid(), ...data }]); log(`Added assignment "${data.title}"`); notify('Assignment added'); }
    setOpen(false);
  };
  const setStatus = (a: Assignment, status: Status) => {
    setAssignments((p) => p.map((x) => (x.id === a.id ? { ...x, status } : x)));
    log(`Marked "${a.title}" as ${status}`); notify('Status updated');
  };
  const del = (a: Assignment) => { if (!window.confirm(`Delete "${a.title}"?`)) return; setAssignments((p) => p.filter((x) => x.id !== a.id)); notify('Assignment deleted'); };
  const sorted = [...assignments].sort((a, b) => a.deadline.localeCompare(b.deadline));

  return (
    <>
      <PageHead title="Assignment Tracker" sub="Never miss a submission deadline" action={<Btn onClick={() => openForm()}>+ Add assignment</Btn>} />
      {sorted.length === 0 ? <Card><Empty text="No assignments yet. Add your first one." /></Card> : (
        <div className="grid gap-4 md:grid-cols-2">
          {sorted.map((a) => {
            const isOpen = a.status !== 'Completed';
            const overdue = isOpen && a.deadline < today();
            const soon = isOpen && !overdue && a.deadline <= addDays(3);
            return (
              <Card key={a.id} className={overdue ? 'ring-2 ring-rose-300' : soon ? 'ring-2 ring-amber-300' : ''}>
                <div className="flex items-start justify-between gap-2">
                  <div><h3 className="font-bold">{a.title}</h3><p className="text-xs font-semibold text-violet-600">{a.subject}</p></div>
                  <Badge cls={overdue ? 'bg-rose-100 text-rose-700' : soon ? 'bg-amber-100 text-amber-700' : STATUS[a.status]}>{overdue ? 'Overdue' : soon ? 'Due soon' : a.status}</Badge>
                </div>
                {a.description && <p className="mt-2 text-sm text-slate-600">{a.description}</p>}
                <p className="mt-2 text-xs text-slate-500">Deadline: {fmtDate(a.deadline)} · Status: {a.status}</p>
                <div className="mt-3 flex flex-wrap items-center gap-3">
                  <select aria-label="Status" className={`${inputCls} !w-auto`} value={a.status} onChange={(e) => setStatus(a, e.target.value as Status)}>{STATUSES.map((s) => <option key={s}>{s}</option>)}</select>
                  <button onClick={() => openForm(a)} className="text-sm text-violet-600 hover:underline">Edit</button>
                  <button onClick={() => del(a)} className="text-sm text-rose-600 hover:underline">Delete</button>
                </div>
              </Card>
            );
          })}
        </div>
      )}
      <Modal open={open} title={edit ? 'Edit assignment' : 'Add assignment'} onClose={() => setOpen(false)}>
        <form onSubmit={submit} className="space-y-4">
          <Field label="Title" error={errs.title}><input className={inputCls} value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} /></Field>
          <Field label="Subject" error={errs.subject}><input className={inputCls} value={f.subject} onChange={(e) => setF({ ...f, subject: e.target.value })} /></Field>
          <Field label="Description"><textarea rows={3} className={inputCls} value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></Field>
          <Field label="Submission deadline" error={errs.deadline}><input type="date" className={inputCls} value={f.deadline} onChange={(e) => setF({ ...f, deadline: e.target.value })} /></Field>
          <Field label="Status"><select className={inputCls} value={f.status} onChange={(e) => setF({ ...f, status: e.target.value as Status })}>{STATUSES.map((s) => <option key={s}>{s}</option>)}</select></Field>
          <Btn type="submit" className="w-full">{edit ? 'Save changes' : 'Add assignment'}</Btn>
        </form>
      </Modal>
    </>
  );
}
