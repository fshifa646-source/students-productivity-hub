import { FormEvent, useState } from 'react';
import { Badge, Btn, Card, Empty, Field, inputCls, Modal, PageHead, PRIO } from '../components/ui';
import { useApp } from '../store';
import { Priority, Task } from '../types';
import { today, uid } from '../lib/utils';

type Filter = 'All' | 'Pending' | 'Completed';

export default function Todos() {
  const { tasks, setTasks, log, notify } = useApp();
  const [filter, setFilter] = useState<Filter>('All');
  const [open, setOpen] = useState(false);
  const [edit, setEdit] = useState<Task | null>(null);
  const [title, setTitle] = useState('');
  const [priority, setPriority] = useState<Priority>('Medium');
  const [err, setErr] = useState('');

  const openForm = (t?: Task) => { setEdit(t ?? null); setTitle(t?.title ?? ''); setPriority(t?.priority ?? 'Medium'); setErr(''); setOpen(true); };
  const submit = (e: FormEvent) => {
    e.preventDefault();
    const v = title.trim();
    if (v.length < 3) return setErr('Task title must be at least 3 characters.');
    if (edit) { setTasks((p) => p.map((t) => (t.id === edit.id ? { ...t, title: v, priority } : t))); log(`Edited task "${v}"`); notify('Task updated'); }
    else { setTasks((p) => [{ id: uid(), title: v, priority, done: false, createdAt: today() }, ...p]); log(`Added task "${v}"`); notify('Task added'); }
    setOpen(false);
  };
  const toggle = (t: Task) => {
    setTasks((p) => p.map((x) => (x.id === t.id ? { ...x, done: !x.done, completedAt: x.done ? undefined : today() } : x)));
    if (!t.done) { log(`Completed task "${t.title}"`); notify('Nice! Task completed'); }
  };
  const del = (t: Task) => {
    if (!window.confirm(`Delete "${t.title}"?`)) return;
    setTasks((p) => p.filter((x) => x.id !== t.id)); log(`Deleted task "${t.title}"`); notify('Task deleted');
  };
  const shown = tasks.filter((t) => filter === 'All' || (filter === 'Pending' ? !t.done : t.done));

  return (
    <>
      <PageHead title="To-Do List" sub={`${tasks.filter((t) => !t.done).length} tasks pending`} action={<Btn onClick={() => openForm()}>+ Add task</Btn>} />
      <div className="mb-4 flex gap-2">
        {(['All', 'Pending', 'Completed'] as Filter[]).map((f) => (
          <button key={f} onClick={() => setFilter(f)} className={`rounded-full px-4 py-1.5 text-sm font-semibold transition ${filter === f ? 'bg-violet-600 text-white' : 'bg-white text-slate-600 ring-1 ring-violet-100 hover:bg-violet-50'}`}>{f}</button>
        ))}
      </div>
      <Card>
        {shown.length === 0 ? <Empty text="No tasks here. Add one to get started." /> : (
          <ul className="divide-y divide-violet-50">
            {shown.map((t) => (
              <li key={t.id} className="flex flex-wrap items-center gap-3 py-3">
                <input type="checkbox" checked={t.done} onChange={() => toggle(t)} aria-label={`Mark "${t.title}" completed`} className="h-5 w-5 accent-violet-600" />
                <span className={`min-w-0 flex-1 text-sm font-medium ${t.done ? 'text-slate-400 line-through' : ''}`}>{t.title}</span>
                <Badge cls={PRIO[t.priority]}>{t.priority}</Badge>
                <button onClick={() => openForm(t)} className="text-sm text-violet-600 hover:underline">Edit</button>
                <button onClick={() => del(t)} className="text-sm text-rose-600 hover:underline">Delete</button>
              </li>
            ))}
          </ul>
        )}
      </Card>
      <Modal open={open} title={edit ? 'Edit task' : 'Add task'} onClose={() => setOpen(false)}>
        <form onSubmit={submit} className="space-y-4">
          <Field label="Task title" error={err}><input autoFocus className={inputCls} value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Finish lab report" /></Field>
          <Field label="Priority">
            <select className={inputCls} value={priority} onChange={(e) => setPriority(e.target.value as Priority)}>
              {['High', 'Medium', 'Low'].map((p) => <option key={p}>{p}</option>)}
            </select>
          </Field>
          <Btn type="submit" className="w-full">{edit ? 'Save changes' : 'Add task'}</Btn>
        </form>
      </Modal>
    </>
  );
}
