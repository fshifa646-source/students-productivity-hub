import { Badge, Bar, Card, Empty, PageHead, STATUS } from '../components/ui';
import { useApp } from '../store';
import { ago, fmtDate, today } from '../lib/utils';

const Stat = ({ label, value, tone }: { label: string; value: number; tone: string }) => (
  <Card className="flex items-center gap-4">
    <div className={`grid h-12 w-12 place-items-center rounded-xl text-xl font-extrabold ${tone}`}>{value}</div>
    <p className="text-sm font-semibold text-slate-600">{label}</p>
  </Card>
);

export default function Dashboard() {
  const { tasks, assignments, activity } = useApp();
  const done = tasks.filter((t) => t.done).length;
  const doneToday = tasks.filter((t) => t.completedAt === today()).length;
  const pending = tasks.length - done;
  const dailyPct = doneToday + pending ? Math.round((doneToday / (doneToday + pending)) * 100) : 0;
  const upcoming = assignments.filter((a) => a.status !== 'Completed').sort((a, b) => a.deadline.localeCompare(b.deadline)).slice(0, 5);
  return (
    <>
      <PageHead title="Hello, Student! 👋" sub={new Date().toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })} />
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <Stat label="Total tasks" value={tasks.length} tone="bg-violet-100 text-violet-700" />
        <Stat label="Completed" value={done} tone="bg-emerald-100 text-emerald-700" />
        <Stat label="Pending" value={pending} tone="bg-amber-100 text-amber-700" />
        <Stat label="Assignments" value={assignments.length} tone="bg-sky-100 text-sky-700" />
      </div>
      <Card className="mt-4">
        <div className="mb-2 flex justify-between text-sm font-semibold"><span>Daily productivity</span><span className="text-violet-700">{dailyPct}%</span></div>
        <Bar pct={dailyPct} />
        <p className="mt-2 text-xs text-slate-500">{doneToday} completed today, {pending} still pending.</p>
      </Card>
      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Card>
          <h2 className="mb-3 font-bold">Upcoming deadlines</h2>
          {upcoming.length === 0 ? <Empty text="No open assignments. Nice work!" /> : (
            <ul className="space-y-2">
              {upcoming.map((a) => {
                const late = a.deadline < today();
                return (
                  <li key={a.id} className="flex items-center justify-between gap-2 rounded-xl bg-violet-50/60 p-3">
                    <div className="min-w-0"><p className="truncate text-sm font-semibold">{a.title}</p><p className={`text-xs ${late ? 'font-semibold text-rose-600' : 'text-slate-500'}`}>{late ? 'Overdue: ' : 'Due '}{fmtDate(a.deadline)}</p></div>
                    <Badge cls={STATUS[a.status]}>{a.status}</Badge>
                  </li>
                );
              })}
            </ul>
          )}
        </Card>
        <Card>
          <h2 className="mb-3 font-bold">Recent activity</h2>
          {activity.length === 0 ? <Empty text="Your activity will show up here." /> : (
            <ul className="space-y-2">
              {activity.slice(0, 6).map((a) => (
                <li key={a.id} className="flex justify-between gap-3 border-b border-violet-50 pb-2 text-sm last:border-0"><span>{a.text}</span><span className="shrink-0 text-xs text-slate-400">{ago(a.at)}</span></li>
              ))}
            </ul>
          )}
        </Card>
      </div>
    </>
  );
}
