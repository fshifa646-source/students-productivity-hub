import { useState } from 'react';
import { Page } from './types';
import Layout, { NAV } from './components/Layout';
import Dashboard from './pages/Dashboard';
import Todos from './pages/Todos';
import Planner from './pages/Planner';
import Assignments from './pages/Assignments';
import Notes from './pages/Notes';
import Progress from './pages/Progress';

const PAGES: Record<Page, () => JSX.Element> = {
  dashboard: Dashboard, todos: Todos, planner: Planner, assignments: Assignments, notes: Notes, progress: Progress,
};

export default function App() {
  const [page, setPage] = useState<Page>(() => {
    const h = window.location.hash.slice(1) as Page;
    return NAV.some((n) => n.id === h) ? h : 'dashboard';
  });
  const go = (p: Page) => { setPage(p); window.location.hash = p; window.scrollTo({ top: 0 }); };
  const View = PAGES[page];
  return <Layout page={page} go={go}><View /></Layout>;
}
