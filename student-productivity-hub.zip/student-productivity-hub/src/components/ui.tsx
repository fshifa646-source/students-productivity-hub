import { ButtonHTMLAttributes, ReactNode } from 'react';

export const Card = ({ children, className = '' }: { children: ReactNode; className?: string }) => (
  <div className={`rounded-2xl bg-white p-5 shadow-sm shadow-violet-200/60 ring-1 ring-violet-100 transition ${className}`}>{children}</div>
);

type BtnProps = ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'primary' | 'soft' | 'danger' };
export const Btn = ({ variant = 'primary', className = '', ...p }: BtnProps) => {
  const v = {
    primary: 'bg-violet-600 text-white hover:bg-violet-700 shadow-sm shadow-violet-300',
    soft: 'bg-violet-50 text-violet-700 hover:bg-violet-100',
    danger: 'bg-rose-50 text-rose-600 hover:bg-rose-100',
  }[variant];
  return <button {...p} className={`rounded-xl px-4 py-2 text-sm font-semibold transition focus:outline-none focus-visible:ring-2 focus-visible:ring-violet-400 ${v} ${className}`} />;
};

export const inputCls =
  'w-full rounded-xl border border-violet-200 bg-white px-3 py-2 text-sm outline-none transition focus:border-violet-500 focus:ring-2 focus:ring-violet-200';

export const Field = ({ label, error, children }: { label: string; error?: string; children: ReactNode }) => (
  <label className="block text-sm font-medium text-slate-600">
    {label}
    <div className="mt-1">{children}</div>
    {error && <p className="mt-1 text-xs text-rose-600">{error}</p>}
  </label>
);

export function Modal({ open, title, onClose, children }: { open: boolean; title: string; onClose: () => void; children: ReactNode }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-40 flex items-end justify-center bg-slate-900/40 p-4 sm:items-center" onMouseDown={onClose}>
      <div className="max-h-[90vh] w-full max-w-md overflow-auto rounded-2xl bg-white p-6 shadow-xl" onMouseDown={(e) => e.stopPropagation()}>
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-bold">{title}</h2>
          <button onClick={onClose} aria-label="Close" className="rounded-lg px-2 text-xl text-slate-400 hover:text-slate-700">×</button>
        </div>
        {children}
      </div>
    </div>
  );
}

export const PageHead = ({ title, sub, action }: { title: string; sub?: string; action?: ReactNode }) => (
  <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
    <div>
      <h1 className="text-2xl font-extrabold tracking-tight text-slate-900">{title}</h1>
      {sub && <p className="text-sm text-slate-500">{sub}</p>}
    </div>
    {action}
  </div>
);

export const Empty = ({ text }: { text: string }) => (
  <p className="rounded-xl border border-dashed border-violet-200 p-6 text-center text-sm text-slate-500">{text}</p>
);

export const Bar = ({ pct, color = 'bg-violet-500' }: { pct: number; color?: string }) => (
  <div className="h-3 w-full overflow-hidden rounded-full bg-violet-100">
    <div className={`h-full rounded-full transition-all duration-500 ${color}`} style={{ width: `${Math.min(100, Math.max(0, pct))}%` }} />
  </div>
);

export const Badge = ({ cls, children }: { cls: string; children: ReactNode }) => (
  <span className={`rounded-full px-2.5 py-0.5 text-xs font-semibold ${cls}`}>{children}</span>
);

export const PRIO: Record<string, string> = { High: 'bg-rose-100 text-rose-700', Medium: 'bg-amber-100 text-amber-700', Low: 'bg-emerald-100 text-emerald-700' };
export const STATUS: Record<string, string> = { 'Not Started': 'bg-slate-100 text-slate-600', 'In Progress': 'bg-sky-100 text-sky-700', Completed: 'bg-emerald-100 text-emerald-700' };
