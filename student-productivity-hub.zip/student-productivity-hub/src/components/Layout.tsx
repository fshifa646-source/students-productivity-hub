import { ReactNode, useState } from 'react';
import { Page } from '../types';
import { useApp } from '../store';

export const NAV: { id: Page; label: string; icon: string }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: '🏠' },
  { id: 'todos', label: 'To-Do', icon: '✅' },
  { id: 'planner', label: 'Planner', icon: '🗓️' },
  { id: 'assignments', label: 'Assignments', icon: '📚' },
  { id: 'notes', label: 'Notes', icon: '📝' },
  { id: 'progress', label: 'Progress', icon: '📈' },
];

export default function Layout({ page, go, children }: { page: Page; go: (p: Page) => void; children: ReactNode }) {
  const [collapsed, setCollapsed] = useState(false);
  const { toast } = useApp();
  return (
    <div className="flex min-h-screen flex-col bg-gradient-to-br from-violet-50 via-white to-sky-50">
      <div className="flex flex-1">
        <aside className={`sticky top-0 hidden h-screen shrink-0 flex-col border-r border-violet-100 bg-white/80 p-3 backdrop-blur transition-all duration-300 md:flex ${collapsed ? 'w-20' : 'w-64'}`}>
          <div className={`mb-6 flex items-center ${collapsed ? 'justify-center' : 'justify-between'} px-2 pt-2`}>
            {!collapsed && <span className="text-lg font-extrabold text-violet-700">🎓 Study Hub</span>}
            <button onClick={() => setCollapsed(!collapsed)} aria-label="Toggle sidebar" className="rounded-lg bg-violet-50 px-2 py-1 text-violet-700 hover:bg-violet-100">
              {collapsed ? '»' : '«'}
            </button>
          </div>
          <nav className="space-y-1">
            {NAV.map((n) => (
              <button key={n.id} onClick={() => go(n.id)} title={n.label}
                className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold transition ${page === n.id ? 'bg-violet-600 text-white shadow shadow-violet-300' : 'text-slate-600 hover:bg-violet-50'} ${collapsed ? 'justify-center' : ''}`}>
                <span className="text-lg">{n.icon}</span>
                {!collapsed && n.label}
              </button>
            ))}
          </nav>
        </aside>
        <main className="min-w-0 flex-1 p-4 md:p-8">{children}</main>
      </div>
      <footer className="py-4 pb-24 text-center text-xs text-slate-500 md:pb-4">Student Productivity Hub © 2026</footer>
      <nav className="fixed inset-x-0 bottom-0 z-30 grid grid-cols-6 border-t border-violet-100 bg-white/95 backdrop-blur md:hidden">
        {NAV.map((n) => (
          <button key={n.id} onClick={() => go(n.id)} className={`flex flex-col items-center py-2 text-[10px] font-semibold ${page === n.id ? 'text-violet-700' : 'text-slate-500'}`}>
            <span className="text-xl">{n.icon}</span>
            {n.label.split(' ')[0]}
          </button>
        ))}
      </nav>
      {toast && (
        <div role="status" className={`fixed right-4 top-4 z-50 rounded-xl px-4 py-3 text-sm font-semibold text-white shadow-lg ${toast.type === 'success' ? 'bg-emerald-600' : 'bg-rose-600'}`}>
          {toast.text}
        </div>
      )}
    </div>
  );
}
