import { Activity, Assignment, Note, Session, Task } from '../types';
import { addDays } from '../lib/utils';

export const sampleTasks = (): Task[] => [
  { id: 't1', title: 'Revise SDLC models for Software Engineering', priority: 'High', done: false, createdAt: addDays(-2) },
  { id: 't2', title: 'Submit lab record for Data Structures', priority: 'High', done: false, createdAt: addDays(-1) },
  { id: 't3', title: 'Read Chapter 5: Software Maintenance', priority: 'Medium', done: false, createdAt: addDays(-1) },
  { id: 't4', title: 'Practice 10 SQL queries', priority: 'Medium', done: true, createdAt: addDays(-3), completedAt: addDays(-1) },
  { id: 't5', title: 'Update GitHub portfolio README', priority: 'Low', done: true, createdAt: addDays(-4), completedAt: addDays(-2) },
  { id: 't6', title: 'Watch OOP concepts lecture', priority: 'Low', done: true, createdAt: addDays(-5), completedAt: addDays(-3) },
  { id: 't7', title: 'Solve previous year question paper', priority: 'High', done: true, createdAt: addDays(-2), completedAt: addDays(0) },
];
export const sampleSessions = (): Session[] => [
  { id: 's1', subject: 'Software Engineering', topic: 'Maintenance & re-engineering', day: 0, start: '09:00', end: '10:30' },
  { id: 's2', subject: 'Data Structures', topic: 'Trees and graphs', day: 1, start: '10:00', end: '11:30' },
  { id: 's3', subject: 'Database Systems', topic: 'Normalization', day: 2, start: '14:00', end: '15:30' },
  { id: 's4', subject: 'Computer Networks', topic: 'TCP/IP layers', day: 3, start: '09:00', end: '10:00' },
  { id: 's5', subject: 'Software Engineering', topic: 'Testing strategies', day: 4, start: '16:00', end: '17:30' },
  { id: 's6', subject: 'Mathematics', topic: 'Discrete math revision', day: 5, start: '11:00', end: '12:30' },
];
export const sampleAssignments = (): Assignment[] => [
  { id: 'a1', title: 'SE Case Study Report', subject: 'Software Engineering', description: 'Compare Agile and Waterfall for a hospital system.', deadline: addDays(3), status: 'In Progress' },
  { id: 'a2', title: 'DBMS Mini Project', subject: 'Database Systems', description: 'Design an ER diagram and schema for a library.', deadline: addDays(7), status: 'Not Started' },
  { id: 'a3', title: 'Data Structures Lab Record', subject: 'Data Structures', description: 'Complete programs 8-12 with outputs.', deadline: addDays(-1), status: 'In Progress' },
  { id: 'a4', title: 'Networks Quiz Prep Sheet', subject: 'Computer Networks', description: 'One-page summary of OSI vs TCP/IP.', deadline: addDays(-4), status: 'Completed' },
];
export const sampleNotes = (): Note[] => [
  { id: 'n1', title: 'Software maintenance types', body: 'Corrective: fix bugs.\nAdaptive: adjust to new environment.\nPerfective: improve performance or features.\nPreventive: reduce future problems.', updatedAt: Date.now() - 3600_000 },
  { id: 'n2', title: 'Exam tips', body: 'Start with revision notes, then solve past papers. Take a 5 minute break every 45 minutes.', updatedAt: Date.now() - 86400_000 },
];
export const sampleActivity = (): Activity[] => [
  { id: 'x1', text: 'Completed task "Solve previous year question paper"', at: Date.now() - 1800_000 },
  { id: 'x2', text: 'Added assignment "SE Case Study Report"', at: Date.now() - 7200_000 },
];
