export type Page = 'dashboard' | 'todos' | 'planner' | 'assignments' | 'notes' | 'progress';
export type Priority = 'High' | 'Medium' | 'Low';
export type Status = 'Not Started' | 'In Progress' | 'Completed';
export interface Task { id: string; title: string; priority: Priority; done: boolean; createdAt: string; completedAt?: string }
export interface Session { id: string; subject: string; topic: string; day: number; start: string; end: string }
export interface Assignment { id: string; title: string; subject: string; description: string; deadline: string; status: Status }
export interface Note { id: string; title: string; body: string; updatedAt: number }
export interface Activity { id: string; text: string; at: number }
export interface ToastMsg { text: string; type: 'success' | 'error' }
